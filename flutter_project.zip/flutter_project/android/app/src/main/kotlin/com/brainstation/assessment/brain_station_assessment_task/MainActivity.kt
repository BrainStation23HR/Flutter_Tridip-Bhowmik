package com.brainstation.assessment.brain_station_assessment_task

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
