import 'package:get/get.dart';

class GlobalState extends GetxController {
  @override
  void onInit() {
    super.onInit();
  }
}
