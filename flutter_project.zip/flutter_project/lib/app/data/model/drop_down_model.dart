class DropDownModel {
  String? id;
  String? title;
  dynamic extraData;

  DropDownModel({this.id, this.title, this.extraData});
}
